<?php

echo $GLOBALS['_W']['config']['setting']['https'];